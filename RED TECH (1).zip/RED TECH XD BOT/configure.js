/*
> Recode script give credits to›
Giddy Tennor

📝 | Created By RED TECH
🖥️ | Base Ori By RED TECH
📝 | Created By RED TECH
📌 |Credits RED TECH
📱 |Chat wa:255742852285 
👑 |Github: RED_TECH
✉️ |Email: redtech474@gmail.com 
*/
const fs = require('fs')
const chalk = require('chalk')
//=================================================//
// setting bot
global.owner = "255742852285 "
global.ownername = "RED TECH"
global.botname = "RED TECH XD"
global.author = "255742852285"
global.xprefix = '.'
global.autostatus = true 
global.Public = true 
//=================================================//
global.egg = "15"
global.loc = "1"
global.domain = ""
global.apikey = ""
global.capikey = ""
//=================================================//
global.mess = {
    owner: '`command reserved for owner only<\>`',
 prem: '`command reserved for premium only<\>`',
    admin: '`command reserved for admins only<\>`',
    group: '`feature for group only<\>`',
    done: '`Done ✓`',
    error: 'Error !',
    success: 'Succes •'
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.green.bold(`Update ${__filename}`))
delete require.cache[file]
require(file)
})